# QuantGrid — Portfolio Management Module

Production-grade Portfolio Management service built with **Clean
Architecture**, **Domain-Driven Design**, **SOLID**, the **Repository
Pattern**, a **Service Layer**, and **Dependency Injection**.

Stack: Python 3.12 · FastAPI · SQLAlchemy 2.0 (async) · PostgreSQL · Redis ·
Pydantic v2 · Alembic.

## Architecture

```
app/
├── core/                          # Cross-cutting concerns (shared by all modules)
│   ├── config.py                  # Settings (env-driven, pydantic-settings)
│   ├── security.py                # JWT auth: create/verify tokens, get_current_user
│   ├── pagination.py              # Shared page/limit query-param dependency
│   └── exceptions.py              # Domain-error -> HTTP response mapping
│
├── modules/portfolio/             # Portfolio Management bounded context
│   ├── domain/                    # Pure business logic. Zero I/O, zero framework imports.
│   │   ├── entities.py            #   Value objects / framework-agnostic DTOs (Money, CashFlow, ...)
│   │   ├── enums.py                #   PortfolioType, TransactionType, AlertType, ...
│   │   ├── exceptions.py          #   Domain errors (mapped to HTTP status codes)
│   │   ├── repositories.py        #   Abstract repository ports (ABCs / Protocols)
│   │   └── calculations/          #   Pure calculation engines (unit-testable, no DB/HTTP)
│   │       ├── position_engine.py #     Weighted-avg-cost accounting (BUY/SELL/BONUS/SPLIT)
│   │       ├── performance.py     #     Daily/weekly/monthly/yearly/absolute return + XIRR
│   │       ├── risk.py            #     Volatility, Sharpe, Sortino, max drawdown, beta, alpha
│   │       ├── analytics.py       #     Allocations, diversification score, health score
│   │       └── rebalancing.py     #     Target-weight drift & buy/sell suggestions
│   │
│   ├── infrastructure/            # I/O adapters implementing the domain's ports
│   │   ├── models.py               #   SQLAlchemy 2.0 ORM models
│   │   ├── database.py             #   Async engine / session-maker / Redis pool factories
│   │   ├── market_data.py          #   Redis-backed MarketDataProvider adapter
│   │   ├── notifier.py             #   Redis pub/sub AlertNotifier adapter
│   │   └── repositories/           #   Concrete SQLAlchemy repository implementations
│   │
│   ├── application/                # Use-case orchestration
│   │   ├── schemas/                 #   Pydantic v2 request/response DTOs
│   │   ├── services/                #   One service per use-case area (see below)
│   │   └── interfaces/              #   Application-level ports (e.g. AlertNotifier Protocol)
│   │
│   └── api/v1/                     # Transport layer (FastAPI)
│       ├── deps.py                  #   DI graph: session -> repositories -> services
│       ├── router.py                #   Aggregates all sub-routers
│       └── routes/                  #   One router per resource
│
└── main.py                         # FastAPI app factory, middleware, exception handlers

alembic/                            # Schema migrations (async)
tests/
├── unit/                           # Pure domain-engine tests (no DB/HTTP)
└── integration/                    # Full HTTP-level tests (in-memory SQLite + fakeredis)
```

**Dependency rule:** `domain` depends on nothing. `application` depends only
on `domain` (via repository/port interfaces). `infrastructure` implements
those interfaces. `api` depends only on `application` (services/schemas),
resolved through `Depends()`. Every calculation engine in `domain/calculations`
is a plain, deterministic, side-effect-free class — this is what makes
`tests/unit` fast and DB-free.

## Features

| Area | Capabilities |
|---|---|
| **Portfolios** | CRUD, archive, live valuation summary (market value / P&L) |
| **Holdings** | CRUD (metadata), live-price enrichment (market value, unrealized P&L) |
| **Transactions** | BUY, SELL, DIVIDEND, BONUS, SPLIT — folded through a weighted-avg-cost engine; delete triggers full position recompute |
| **Performance** | Daily / weekly / monthly / yearly / absolute return, XIRR (money-weighted, Newton-Raphson + bisection fallback) |
| **Risk** | Sharpe ratio, Sortino ratio, annualized volatility, max drawdown, beta, Jensen's alpha (vs. configurable benchmark) |
| **Analytics** | Sector / market-cap / asset-class allocation, top holdings, HHI-based diversification score, benchmark comparison, composite health score |
| **Watchlists** | CRUD + item add/remove |
| **Alerts** | Target-price & stop-loss alerts, price-triggered evaluation + notification |
| **Rebalancing** | Target-weight drift analysis with BUY/SELL/HOLD suggestions and a tolerance band |
| **Cross-cutting** | JWT auth, pagination, filtering, sorting, request validation, OpenAPI docs |

## Running locally

```bash
python3.12 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

export QUANTGRID_DATABASE_URL="postgresql+asyncpg://quantgrid:quantgrid@localhost:5432/quantgrid"
export QUANTGRID_REDIS_URL="redis://localhost:6379/0"
export QUANTGRID_JWT_SECRET_KEY="replace-me"

alembic upgrade head
uvicorn app.main:app --reload
```

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`
- Health check: `GET /health`

Market data (live quotes, price history, security metadata) is read from
Redis keys (`quantgrid:market:price:{symbol}`, etc.) — see
`app/modules/portfolio/infrastructure/market_data.py` for the exact contract.
Populating those keys is the job of a separate market-data ingestion
pipeline; this module only *consumes* them through the `MarketDataProvider`
port, so any vendor integration can be swapped in without touching domain or
application code.

## Testing

```bash
pip install -r requirements.txt
pytest                       # unit + integration (57 tests, no external services required)
pytest tests/unit -v         # pure domain-engine tests only
pytest tests/integration -v  # full HTTP-level tests (in-memory SQLite + fakeredis)
```

## Database migrations

```bash
alembic upgrade head          # apply
alembic revision -m "..."     # create a new revision (hand-write or autogenerate against a live DB)
alembic downgrade -1          # roll back one revision
```
