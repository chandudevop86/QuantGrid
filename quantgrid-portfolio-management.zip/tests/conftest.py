from __future__ import annotations

import asyncio
import uuid
from collections.abc import AsyncGenerator

import fakeredis
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from app.core.security import create_access_token
from app.modules.portfolio.infrastructure.models import Base


@pytest_asyncio.fixture
async def fake_redis() -> AsyncGenerator[fakeredis.aioredis.FakeRedis, None]:
    client = fakeredis.aioredis.FakeRedis(decode_responses=True)
    yield client
    await client.aclose()


@pytest_asyncio.fixture
async def async_engine():
    """In-memory SQLite (aiosqlite) engine, isolated per test."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(async_engine) -> AsyncGenerator[AsyncSession, None]:
    session_factory = async_sessionmaker(bind=async_engine, expire_on_commit=False, class_=AsyncSession)
    async with session_factory() as session:
        yield session


@pytest.fixture
def test_user_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def auth_headers(test_user_id) -> dict:
    token = create_access_token(subject=test_user_id, email="trader@quantgrid.dev")
    return {"Authorization": f"Bearer {token}"}


@pytest_asyncio.fixture
async def client(async_engine, auth_headers, fake_redis) -> AsyncGenerator[AsyncClient, None]:
    """
    An httpx AsyncClient wired to the FastAPI app, with the DB session and
    Redis client dependencies overridden to use an in-memory SQLite engine
    and fakeredis respectively, so tests never require live infrastructure.
    """
    from app.main import app
    from app.modules.portfolio.api.v1 import deps as portfolio_deps

    session_factory = async_sessionmaker(bind=async_engine, expire_on_commit=False, class_=AsyncSession)

    async def _override_get_session():
        async with session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise

    async def _override_get_redis():
        yield fake_redis

    # These are the exact callables routes depend on (via
    # `app.modules.portfolio.api.v1.deps`), which internally wrap
    # `app.modules.portfolio.infrastructure.database`'s engine/session-maker.
    # Overriding at this layer is what FastAPI's dependency_overrides matches.
    app.dependency_overrides[portfolio_deps.get_session] = _override_get_session
    app.dependency_overrides[portfolio_deps.get_redis] = _override_get_redis

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", headers=auth_headers) as ac:
        yield ac

    app.dependency_overrides.clear()
